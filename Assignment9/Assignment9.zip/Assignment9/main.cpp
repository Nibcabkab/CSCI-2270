#include <iostream>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "hashtable.h"
using namespace std;

int main(int arg, char* argv[])
{
    HashTable *movieTable = new HashTable(1);
    while(true){
    cout<<"======Main Menu====="<<endl;
    cout<<"1. Insert movie"<<endl;
    cout<<"2. Delete movie"<<endl;
    cout<<"3. Find movie"<<endl;
    cout<<"4. Print table contents"<<endl;
    cout<<"5. Quit"<<endl;
    string selection;
    getline(cin, selection);
    if(selection == "1"){
        string title;
        cout<<"Enter title:"<<endl;
        getline(cin, title);
        string year;
        cout<<"Enter year:"<<endl;
        getline(cin, year);
    }
    if(selection == "2"){
        string title;
        cout<<"Enter title:"<<endl;
        getline(cin, title);
    }
    if(selection == "3"){
        string title;
        cout<<"Enter title:"<<endl;
        getline(cin, title);
    }

    if(selection == "4"){

    }
    if(selection == "5"){
        cout<<"Goodbye!";
        break;
    }
    }
}
