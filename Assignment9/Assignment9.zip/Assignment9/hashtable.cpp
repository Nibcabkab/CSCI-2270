#include <iostream>
#include "hashtable.h""
using namespace std;

HashTable::HashTable(int i){
cout<<""<<endl;
}
